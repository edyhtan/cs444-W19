package Joosc.Exceptions;

public class TypeCheckException extends Exception {

    public TypeCheckException(String msg) {
        super(msg);
    }
}
