package Joosc.ASTModel.ClassMember;

public interface Method {
}
