package Joosc.ASTModel.ClassMember;

import Joosc.Environment.LocalEnv;

public interface Method {
    void addLocalEnvironment(LocalEnv localEnv);
}
