package Joosc.ASTModel;

public interface AST {
}
