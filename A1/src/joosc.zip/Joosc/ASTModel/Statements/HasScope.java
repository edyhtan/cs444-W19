package Joosc.ASTModel.Statements;

import java.util.ArrayList;

public interface HasScope {
    ArrayList<Statement> getBlock();
}
