package Joosc.ASTModel.Expressions;

import Joosc.ASTBuilding.ASTStructures.Expressions.*;
import Joosc.ASTBuilding.Constants.Symbol;
import Joosc.ASTModel.AST;

public abstract class Expression extends HasType implements AST {
    Symbol kind;
     public static Expression convertExpressionNode(ExpressionNode node) {
        if(node instanceof ExpressionBinaryNode) {
            return new ExpressionBinary((ExpressionBinaryNode) node);
        }

        if(node instanceof ExpressionUnaryNode) {
            return new ExpressionUnary((ExpressionUnaryNode) node);
        }

        if(node instanceof ExpressionContentNode) {
            return ExpressionContent.getContent((ExpressionContentNode) node);
        }

        if(node instanceof ExpressionMethodInvocationNode) {
            return new ExpressionMethodInvocation((ExpressionMethodInvocationNode) node);
        }

        if(node instanceof ExpressionClassInstanceCreationNode) {
            return new ExpressionClassInstanceCreation((ExpressionClassInstanceCreationNode) node);
        }

        if(node instanceof ExpressionFieldAccessNode) {
             return new ExpressionFieldAccess((ExpressionFieldAccessNode) node);
        }
        return null;
    }
}
