package Joosc.ASTModel.Expressions;

public abstract class ExpressionPrimary extends Expression {
}
