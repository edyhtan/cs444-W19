package Joosc.ASTModel.Expressions;

public interface ExpressionPrimary extends Expression {
}
