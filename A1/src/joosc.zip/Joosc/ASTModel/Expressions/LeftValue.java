package Joosc.ASTModel.Expressions;

public interface LeftValue {
    void getCodeAddr(int indent);
}
