package Joosc.ASTModel.Expressions;

import Joosc.Exceptions.NamingResolveException;

public class This extends ExpressionContent {
    @Override
    public void validate() throws NamingResolveException {

    }
}
