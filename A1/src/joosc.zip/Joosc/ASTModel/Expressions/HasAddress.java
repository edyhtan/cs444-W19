package Joosc.ASTModel.Expressions;

interface HasAddress {
    void getCodeAddr(int indent);
}
