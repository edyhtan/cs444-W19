package Joosc.AST.ASTStructures.Statements;

import Joosc.Exceptions.WeedingFailureException;

public class ForStatement extends StatementNode {
    @Override
    public void weed() throws WeedingFailureException { }

    @Override
    public void printInfo(int level) { }
}
