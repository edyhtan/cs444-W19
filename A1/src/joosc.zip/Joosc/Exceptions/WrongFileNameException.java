package Joosc.Exceptions;

public class WrongFileNameException extends Exception {
    public WrongFileNameException(String msg) {
        super(msg);
    }
}
