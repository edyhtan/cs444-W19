package Joosc.Exceptions;

public abstract class ASTException extends JoosException {
    public ASTException() {
        super();
    }
}
