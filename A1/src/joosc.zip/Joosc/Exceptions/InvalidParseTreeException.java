package Joosc.Exceptions;

public class InvalidParseTreeException extends JoosException {
    public InvalidParseTreeException(String msg) {
        super(msg);
    }
}
