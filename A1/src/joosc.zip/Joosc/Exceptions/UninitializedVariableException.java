package Joosc.Exceptions;

public class UninitializedVariableException extends Exception {
    public UninitializedVariableException(String msg) {
        super(msg);
    }
}
