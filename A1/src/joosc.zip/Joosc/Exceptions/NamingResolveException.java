package Joosc.Exceptions;

public class NamingResolveException extends Exception {
    public NamingResolveException(String msg) {
        super(msg);
    }
}
