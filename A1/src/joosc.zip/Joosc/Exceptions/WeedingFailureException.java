package Joosc.Exceptions;

public class WeedingFailureException extends Exception {
    public WeedingFailureException() {
        super("Error in weeding");
    }
}
