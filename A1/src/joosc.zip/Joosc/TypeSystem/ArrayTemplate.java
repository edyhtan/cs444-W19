public class ArrayTemplate extends Object implements java.lang.Cloneable, java.io.Serializable {
    public Object __;
    public int length;
}
