package Joosc.TypeSystem;

import Joosc.ASTBuilding.JoosAST;
import Joosc.ASTModel.ClassInterface.ClassDeclr;
import Joosc.ASTModel.Program;
import Joosc.AsmWriter.AsmWriter;
import Joosc.AsmWriter.Register;
import Joosc.Environment.ClassEnv;
import Joosc.Environment.GlobalEnv;
import Joosc.Exceptions.ASTException;
import Joosc.Joosc;
import Joosc.Parser.JoosParse;
import Joosc.Scanner.JoosScan;
import Joosc.Token.Token;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class ArrayType extends JoosType{
    JoosType joosType;
    public static ClassEnv illusionaryEnv;
    public static Program program;

    public ArrayType(ClassEnv classEnv) {
        super(classEnv);
        this.joosType = new JoosType(classEnv);
    }

    public ArrayType(JoosType joosType) {
        super(joosType);
        this.joosType = joosType;
    }

    // check primitive types
    public boolean equals(ArrayType arrayType) {
        return this.joosType.getTypeName().equals(arrayType.joosType.typeName);
    }

    public boolean equals(JoosType joosType) {
        if (joosType instanceof ArrayType) {
            return this.equals((ArrayType) joosType);
        } else {
            return false;
        }
    }

    public boolean isA(JoosType type) {
        if (type instanceof ArrayType) {
            return this.joosType.isA(((ArrayType)type).joosType);
        }

        return type.equals(getJoosType(new ArrayList<>(Arrays.asList("java", "lang", "Object"))))
                || type.equals(getJoosType(new ArrayList<>(Arrays.asList("java", "lang", "Cloneable"))))
                || type.equals(getJoosType(new ArrayList<>(Arrays.asList("java", "io", "Serializable"))))
                || type.equals(NULL);
    }

    public boolean assignable(JoosType type) {
        if (type instanceof ArrayType) {
            if (joosType.equals(JoosType.getJoosType("int")) &&
                    ((ArrayType) type).getJoosType().equals(JoosType.getJoosType("byte"))) {
                return false; // special case
            }
            return this.getJoosType().assignable(((ArrayType) type).getJoosType());
        }
        return type.equals(NULL);
    }

    public ArrayList<String> getTypeName() {
        ArrayList<String> arr = new ArrayList<>(super.getTypeName());
        arr.add("[]");
        return arr;
    }

    public String getQualifiedName() {
        return String.join(".", joosType.getTypeName()) + "[]";
    }

    public JoosType getJoosType() {
        return joosType;
    }

    public ClassEnv getClassEnv() {
        return illusionaryEnv;
    }

    public static void initIllusion() {
        try {
            JoosScan scan = new JoosScan(new File((Joosc.IDE_FLAG ? "src/" : "") + "Joosc/TypeSystem/ArrayTemplate.java"));
            scan.scan();
            JoosParse parse = new JoosParse();
            parse.parse(scan.getOutput());
            program = new Program(new JoosAST(parse.getTree()).getRoot());
            illusionaryEnv = new ClassEnv(program, GlobalEnv.instance);
            illusionaryEnv.semanticAnalysis();
            illusionaryEnv.variableContain();
            illusionaryEnv.joosType = new JoosType(illusionaryEnv);
            illusionaryEnv.buildMethodCallTable();
            illusionaryEnv.buildSymbolTable();
            illusionaryEnv.buildConstructorLabel();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void createArrayCaller() {
        program.codeGen(0);
        AsmWriter writer = ((ClassDeclr)program.getTypeDeclr()).getWriter();

        writer.println();
        writer.comment("eax: size of the array");
        writer.comment("ebx: 0 for number, -1 for boolean, or classTAG");
        writer.global("__new_array");
        writer.label("__new_array");
        writer.extern("__malloc");
        writer.indent(1);
        writer.push(Register.eax);
        writer.indent(1);
        writer.push(Register.ebx);
        writer.indent(1);
        writer.add(Register.eax, 3);
        writer.indent(1);
        writer.imul(Register.eax, 4);
        writer.indent(1);
        writer.call("__malloc");
        writer.indent(1);
        writer.pop(Register.ebx);
        writer.indent(1);
        writer.movToAddr(Register.eax+ "+4", Register.ebx);
        writer.indent(1);
        writer.pop(Register.ebx);
        writer.indent(1);
        writer.movToAddr(Register.eax+ "+8", Register.ebx);
        writer.indent(1);
        writer.ret();
        writer.close();
    }
}
